"""Boundary checks run without private source exports or third-party packages."""
from pathlib import Path
import sqlite3
import unittest

SQL=Path(__file__).resolve().parents[1]/'sql'

class TaskLogic(unittest.TestCase):
    def setUp(self):
        self.db=sqlite3.connect(':memory:')
        self.db.create_function('lower',1,lambda x:x.lower() if x is not None else None)
        self.db.executescript('''
        CREATE TABLE orders(order_id TEXT, order_date TEXT, warehouse_id TEXT, user_id TEXT);
        CREATE TABLE order_lines(order_id TEXT, product_id TEXT, price REAL, quantity INTEGER);
        CREATE TABLE products(product_id TEXT, product TEXT, category TEXT);
        CREATE TABLE warehouses(warehouse_id TEXT, city TEXT, address TEXT);
        INSERT INTO warehouses VALUES ('s','Санкт-Петербург',''),('m','Москва','');
        INSERT INTO products VALUES
          ('a','Корм A','Продукция для животных'),
          ('b','Паштет B','Продукция для животных'),
          ('x','Корм Kitekat для кошек, с кроликом в соусе, 85 г','Продукция для животных'),
          ('t','Лакомство T','Продукция для животных');
        ''')
    def tearDown(self):self.db.close()
    def order(self,oid,date,user,city='s',lines=()):
        self.db.execute('INSERT INTO orders VALUES (?,?,?,?)',(oid,date,city,user))
        self.db.executemany('INSERT INTO order_lines VALUES (?,?,1,?)',[(oid,p,q) for p,q in lines])
    def test_task2_units_dates_and_excluded_sku(self):
        self.order('1','2017-08-01','1',lines=[('a',2),('x',9)])
        self.order('2','2017-08-15','2',lines=[('a',1)])
        self.order('3','2017-08-15','2',lines=[('b',1)])
        self.order('4','2017-08-16','3',lines=[('a',2)])
        self.order('5','2017-08-15','4',lines=[('t',2),('x',2)])
        self.order('6','2017-08-15','5',lines=[('a',1)])
        rows=self.db.execute((SQL/'task2_users.sql').read_text(encoding='utf-8')).fetchall()
        self.assertEqual(rows,[('1',),('2',)])
    def test_task3_global_first_city_tie_frequency_unknown_and_end_date(self):
        self.order('1','2017-08-01','1','m',[('a',1)])
        self.order('3','2017-08-15','1',lines=[('a',100)])
        self.order('10','2017-08-15','2',lines=[('a',100)])
        self.order('2','2017-08-15','2',lines=[('b',8),('b',8),('unknown',1)])
        self.order('20','2017-08-30','3',lines=[('b',1)])
        self.order('21','2017-08-31','4',lines=[('a',100)])
        self.order('22','2017-08-16','5','m',[('a',100)])
        self.order('23','2017-08-16','6',lines=[])
        rows=self.db.execute((SQL/'task3_top_products.sql').read_text(encoding='utf-8')).fetchall()
        self.assertEqual(rows,[('b','Паштет B',2),('unknown','Нет в справочнике',1)])

if __name__=='__main__':unittest.main()
