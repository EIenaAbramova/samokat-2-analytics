"""Independent audit of original exports. Does not transform Power BI input files."""
from pathlib import Path
import argparse, hashlib, json, sqlite3
import pandas as pd

def run(source: Path, target: Path):
    target.mkdir(parents=True, exist_ok=True)
    tables, audit, hashes = {}, {}, {}
    for name, enc, sep, key in [('orders','utf-8',',','order_id'),('order_lines','utf-8','\t',None),('products','mac_cyrillic',',','product_id'),('warehouses','utf-8',',','warehouse_id')]:
        f=next(source.glob(name+' -*'))
        hashes[f.name]=hashlib.sha256(f.read_bytes()).hexdigest()
        d=pd.read_csv(f,encoding=enc,sep=sep,dtype=str)
        audit[name]={'raw_rows':len(d),'exact_duplicate_rows':int(d.duplicated().sum())}
        if key:
            unique=d.drop_duplicates()
            if unique.duplicated(key).any(): raise ValueError('Conflicting dimension key: '+name)
            d=unique
        for c in d.columns: d[c]=d[c].str.strip()
        if name=='order_lines':
            d['price']=pd.to_numeric(d.price.str.replace(',','.',regex=False))
            d['quantity']=pd.to_numeric(d.quantity)
            assert (d.price>=0).all() and (d.quantity>0).all()
        tables[name]=d
        audit[name]['model_rows']=len(d)
    o,l,p,w=[tables[n] for n in ['orders','order_lines','products','warehouses']]
    x=l.merge(o,on='order_id',how='left',validate='many_to_one',indicator=True)
    orphan_lines=int((x['_merge']!='both').sum())
    x=x.drop(columns='_merge').merge(p,on='product_id',how='left',validate='many_to_one').merge(w,on='warehouse_id',how='left',validate='many_to_one')
    x['revenue']=x.price*x.quantity
    missing=~o.order_id.isin(l.order_id)
    foods=p[p.category.str.lower().eq('продукция для животных') & p['product'].str.lower().str.match(r'^(корм|паштет) ') & ~p['product'].str.lower().eq('корм kitekat для кошек, с кроликом в соусе, 85 г')]
    z=x[x.order_date.between('2017-08-01','2017-08-15') & x.product_id.isin(foods.product_id)]
    users=z.groupby('user_id').agg(units=('quantity','sum'),skus=('product_id','nunique'))
    ids=sorted(users.index[users.units>=2],key=int)
    pd.DataFrame({'user_id':ids}).to_csv(target/'task2_users.csv',index=False,encoding='utf-8')
    users.loc[ids].reset_index().to_csv(target/'task2_audit.csv',index=False,encoding='utf-8')
    db=sqlite3.connect(':memory:')
    db.create_function('lower',1,lambda value:value.lower() if value is not None else None)
    for n,d in tables.items():d.to_sql(n,db,index=False)
    sql_root=Path(__file__).resolve().parents[1]/'sql'
    s2=pd.read_sql_query((sql_root/'task2_users.sql').read_text(encoding='utf-8'),db)
    assert s2.user_id.tolist()==ids, 'SQL / pandas mismatch'
    top=pd.read_sql_query((sql_root/'task3_top_products.sql').read_text(encoding='utf-8'),db)
    top.to_csv(target/'task3_top5.csv',index=False,encoding='utf-8-sig')
    first=o.assign(order_sort=o.order_id.astype('int64')).sort_values(['order_date','order_sort']).drop_duplicates('user_id')
    first=first.merge(w,on='warehouse_id',how='left')
    first=first[first.order_date.between('2017-08-15','2017-08-30') & first.city.eq('Санкт-Петербург')]
    py_top=l[l.order_id.isin(first.order_id)].groupby('product_id').order_id.nunique().reset_index(name='first_order_count').sort_values(['first_order_count','product_id'],ascending=[False,True]).head(5)
    assert py_top[['product_id','first_order_count']].to_dict('records')==top[['product_id','first_order_count']].to_dict('records')
    daily=o.groupby('order_date').size().rename('orders').to_frame().join(o[missing].groupby('order_date').size().rename('orders_without_lines')).fillna(0).join(x.groupby('order_date').revenue.sum())
    daily['aov_all']=daily.revenue/daily.orders
    daily['aov_with_lines']=daily.revenue/(daily.orders-daily.orders_without_lines)
    daily.to_csv(target/'daily.csv',encoding='utf-8')
    cats=x.fillna({'category':'Нет в справочнике'}).groupby('category').revenue.sum().sort_values(ascending=False)
    cats.to_csv(target/'categories.csv',encoding='utf-8-sig')
    summary={'audit':audit,'revenue':float(x.revenue.sum()),'orders':len(o),'users_all_ids':int(o.user_id.nunique()),'orders_without_lines':int(missing.sum()),'orders_without_warehouse':int((~o.warehouse_id.isin(w.warehouse_id)).sum()),'revenue_without_product':float(x.loc[x['product'].isna(),'revenue'].sum()),'unknown_product_ids':int(x.loc[x['product'].isna(),'product_id'].nunique()),'invalid_product_id_lines':int((~l.product_id.str.fullmatch(r'\d+')).sum()),'invalid_user_orders':int((~o.user_id.str.fullmatch(r'\d+')).sum()),'task2_users':len(ids),'task2_exactly_2_units':int(users.units.eq(2).sum()),'task2_at_least_2_skus':int(users.skus.ge(2).sum()),'task2_food_skus':len(foods),'task2_old_category_rule_users':int(x[x.order_date.between('2017-08-01','2017-08-15') & x.category.eq('Продукция для животных') & ~x.product_id.eq('3107')].groupby('user_id').quantity.sum().ge(2).sum()),'first_orders_spb_period':len(first),'top5':top.to_dict('records'),'period':[o.order_date.min(),o.order_date.max()],'source_sha256':hashes,'checks':['unique dimension keys','all lines have headers','nonnegative price and positive quantity','task2 SQL equals pandas','task3 SQL equals pandas']}
    summary['orphan_lines']=orphan_lines
    summary['orphan_revenue']=float(x.loc[x.order_date.isna(),'revenue'].sum())
    summary['revenue_matched_orders']=float(x.loc[x.order_date.notna(),'revenue'].sum())
    summary['checks'].remove('all lines have headers')
    (target/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in summary.items() if k!='source_sha256'},ensure_ascii=False,indent=2))
    return summary

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'output');a=ap.parse_args();run(a.source,a.output)
